<!-- Navigation Bar -->
    <nav class="navbar navbar-expand-md">
        <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="btn nav-btn nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                </li>            
                <li class="nav-item">
                    <a class="btn nav-btn nav-link" href="<?php echo e(url('/services')); ?>">Layanan</a>
                </li>
                <li class="nav-item">
                    <a class="btn nav-btn nav-link" href="<?php echo e(url('/aboutus')); ?>">Tentang Kami</a>
                </li>            
            </ul>
        </div>
        <div class="mx-auto order-0">
        <a class="navbar-brand mx-auto" href="/"><img class="logo" src="<?php echo e(asset('images/Logo On Laundry.png')); ?>"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".dual-collapse2">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
        <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
            <ul class="navbar-nav ml-auto">                   
                <li class="nav-item">
                    <a class="btn nav-btn nav-link" href="<?php echo e(url('/order')); ?>">Order</a>
                </li>
                <li class="nav-item">
                    <a class="btn nav-btn nav-link" href="<?php echo e(url('/login')); ?>">Login/Register</a>
                </li>                
            </ul>
        </div>
    </nav><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/layout/navbar.blade.php ENDPATH**/ ?>