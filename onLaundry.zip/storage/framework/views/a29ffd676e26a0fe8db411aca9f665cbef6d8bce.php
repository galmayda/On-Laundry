<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->	  
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/flaticon/flaticon.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
    
    <title><?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <body>

    <!-- Navigation Bar -->
        <nav class="navbar navbar-expand-md">
            <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <button class="btn nav-btn nav-link" href="#">Home</button>
                    </li>            
                    <li class="nav-item">
                        <button class="btn nav-btn nav-link" href="#">Layanan</button>
                    </li>
                    <li class="nav-item">
                        <button class="btn nav-btn nav-link" href="#">Tentang Kami</button>
                    </li>            
                </ul>
            </div>
            <div class="mx-auto order-0">
            <a class="navbar-brand mx-auto" href="/"><img class="logo" src="<?php echo e(asset('images/Logo On Laundry.png')); ?>"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".dual-collapse2">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
                <ul class="navbar-nav ml-auto">                   
                    <li class="nav-item">
                        <button class="btn nav-btn nav-link" href="#"><a href="order">Order</a> </button>
                    </li>
                    <li class="nav-item">
                        <button class="btn nav-btn nav-link" href="#"><a href="login">Login</a></button>
                    </li>
                    <li class="nav-item">
                        <button class="btn nav-btn nav-link" href="#"><a href="register">Register</a></button>
                    </li>
                </ul>
            </div>
        </nav>

        <?php echo $__env->yieldContent('container'); ?>

    <!-- Footer -->
	<footer class="footer">
            <div class="container">      	
              <div class="row mb-5">
                <div class="col-md">
                  <div class="ftco-footer-widget mb-4">
                    <h2 class="ftco-heading-2"><img class="logo" src="<?php echo e(asset('images/Logo On Laundry.png')); ?>"></h2>
                    <p>Laundry terbaik dan berkualitas di Telkom University untuk kebutuhan daily Laundry Anda.</p>                    
                  </div>
                </div>
                <div class="col-md">
                  <div class="ftco-footer-widget mb-4 ml-md-5">
                    <h3 class="ftco-heading-2">Info</h3>
                    <ul class="list-unstyled">
                      <li><a href="#" class="py-2 d-block">Layanan</a></li>
                      <li><a href="#" class="py-2 d-block">Tentang Kami</a></li>                
                      <li><a href="#" class="py-2 d-block">Hubungi Kami</a></li>
                    </ul>
                  </div>
                </div>
                      <div class="col-md">
                          <aside class="follow-tab">
                              <div class="follow-title">
                                  <h3>Follow Us</h3>
                              </div>						
                              <ul class="list-unstyled">
                                  <li><a href="#"><i class="fa fa-facebook"></i>Facebook : On-Laundry </a></li>
                                  <li><a href="#"><i class="fa fa-twitter"></i>Twitter   : @onlaundrytelu  </a></li>							
                              </ul>
                          </aside>
                      </div>
              </div>
              <div class="row">
                <div class="col-md-12 text-center">
                  <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
                </div>
              </div>
            </div>
          </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery, Popper.js, Bootstrap JS, WOW JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('js/wow.min.js')); ?>"></script>
              <script>
              new WOW().init();
              </script>
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/layout/main.blade.php ENDPATH**/ ?>