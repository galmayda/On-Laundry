<!-- Footer -->
    <footer class="footer">
        <div class="container">      	
          <div class="row mb-5">
            <div class="col-md">
              <div class="description-tab mb-4">
                <h2 class="heading"><img class="logofooter" src="<?php echo e(asset('images/Logo On Laundry.png')); ?>"></h2>
                <p>Laundry terbaik dan berkualitas di Telkom University untuk kebutuhan daily Laundry Anda.</p>                    
              </div>
            </div>
            <div class="col-md">
              <div class="info-tab mb-4 ml-md-5">
                <h3 class="info-title">Info</h3>
                <ul class="list-unstyled">
                  <li><a href="#" class="py-2 d-block">Layanan</a></li>
                  <li><a href="#" class="py-2 d-block">Tentang Kami</a></li>                
                  <li><a href="#" class="py-2 d-block">Hubungi Kami</a></li>
                </ul>
              </div>
            </div>
                  <div class="col-md">
                      <aside class="follow-tab">
                          <div class="follow-title">
                              <h3>Follow Us</h3>
                          </div>						
                          <ul class="list-unstyled">
                              <li><a href="#"><i class="fa fa-facebook"></i>Facebook : On-Laundry </a></li>
                              <li><a href="#"><i class="fa fa-twitter"></i>Twitter   : @onlaundrytelu  </a></li>							
                          </ul>
                      </aside>
                  </div>
          </div>
          <div class="row">
            <div class="col-md-12 text-center">
              <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
            </div>
          </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>